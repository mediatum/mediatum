/*
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	
//CKEDITOR.plugins.addExternal( 'insertText', CKEDITOR.basePath + 'plugins/InsertText/' );	 
//config.extraPlugins = "insertText";	

CKEDITOR.plugins.addExternal( 'frontendmodules', CKEDITOR.basePath + 'plugins/frontendmodules/' );	
config.extraPlugins = "frontendmodules";	
 
//CKEDITOR.config.toolbar = 'MyToolbar2';
 
config.toolbar_MyToolbar =
[
         ['NewPage','insertText','frontendmodules'],
];    
    

config.toolbar_MyToolbar2 =
[
         ['NewPage'],
];    
        
    
config.toolbar_Full =
[
    ['Source'],
    ['Cut','Copy','Paste','PasteText','PasteFromWord','-','Print', 'SpellChecker', 'Scayt'],
    ['Undo','Redo','-','Find','Replace','-','SelectAll','RemoveFormat'],
    '/',
    ['Bold','Italic','Underline','Strike','-','Subscript','Superscript'],
    ['NumberedList','BulletedList','-','Outdent','Indent','Blockquote','CreateDiv'],
    ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
    ['Link','Unlink','Anchor'],
    ['Image','frontendmodules','Table','HorizontalRule','Smiley','SpecialChar'],
    '/',
    ['Styles','Format','Font','FontSize'],
    ['TextColor','BGColor'],
    ['Maximize', 'ShowBlocks','-','About']
];
config.language = 'fr';    
config.height = '500px';

config.contentsCss = ['/css/ckeditor.css'];

/*
config.stylesSet = [
 { name : 'Strong Mediatum', element : 'strong' },
{ name : 'Mediatum', element : 'blue' }];
*/

};
