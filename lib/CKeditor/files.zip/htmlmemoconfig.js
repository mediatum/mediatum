/*
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
    config.toolbar_Full =
    [
        ['Source','-', 'Undo', 'Redo', '-', 'Paste','PasteText','PasteFromWord','RemoveFormat', '-', 'Maximize'],
        '/',
        ['Bold','Italic','Underline','Strike','-','Subscript','Superscript', '-','TextColor','BGColor', '-', 'JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
    ];
    config.height = '300px';

    config.contentsCss = ['/css/ckeditor.css'];
};
