CKEDITOR.plugins.add('insertText', {
	init : function( editor )
	{
		editor.addCommand( 'insertTextDlg', new CKEDITOR.dialogCommand( 'insertTextDlg' ) );
 
		editor.ui.addButton( 'insertText',
			{
				label : 'Text einf�gen',
				command : 'insertTextDlg',
				icon: CKEDITOR.basePath + 'plugins/InsertText/ajax-loader.gif'
			});
 
		CKEDITOR.dialog.add( 'insertTextDlg', CKEDITOR.basePath + 'plugins/InsertText/insertTextDlg.js');
 
	}
});