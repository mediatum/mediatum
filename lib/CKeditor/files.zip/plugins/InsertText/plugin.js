function FrontendModules()
{
}

// Disable button toggling.
FrontendModules.prototype.GetState = function()
{
	return FCK_TRISTATE_OFF;
}

// Our method which is called on button click.
FrontendModules.prototype.Execute = function()
{
}

CKEDITOR.plugins.add('insertText', {
    requires: ['iframedialog'],

	init : function( editor )
	{
		CKEDITOR.dialog.addIframe('testname', 'testtitle', 'http://www.google.com', 300, 300, function() {}); //.add( 'insertTextDlg', CKEDITOR.basePath + 'plugins/InsertText/test.js');

        //var dialog = new CKEDITOR.dialogCommand( 'insertTextDlg' );
		//editor.addCommand( 'insertTextDlg', {exec:showDialogPlugin});
        editor.addCommand( 'googlevcvvdvs', {exec: function(e) {e.openDialog('testname');}});

		editor.ui.addButton( 'insertText',
			{
				label : 'Text einf�gen',
				command : 'insertTextDlg',
				icon: CKEDITOR.basePath + '/plugins/InsertText/ajax-loader.gif'
			});
        
 
        //CKEDITOR.dialog.addUIElement("uiname", showDialogPlugin)
	}
});

function showDialogPlugin(e){
    alert('helloworld.dlg');
    new CKEDITOR.dialogCommand( 'frontendmodules', 'Module', '/modules/init/editor', 500, 350 ) ;
    //CKEDITOR.dialog(ed, "dfsdddf");
}

onContentLoad : function()
{
   var iframe = document.getElementById( this._.frameId ),
      iframeWindow = iframe.contentWindow;
}