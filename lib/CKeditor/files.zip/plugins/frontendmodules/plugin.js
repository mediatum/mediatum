function FrontendModules()
{
}

// Disable button toggling.
FrontendModules.prototype.GetState = function()
{
	return FCK_TRISTATE_OFF;
}

// Our method which is called on button click.
FrontendModules.prototype.Execute = function()
{
}

CKEDITOR.plugins.add('frontendmodules',
{
	requires: ['iframedialog'],
	init: function(editor)
	{
		var pluginName = 'frontendmodules';
		var mypath = this.path;
		CKEDITOR.dialog.addIframe( pluginName, 'My Plug-in', '/modules/init/editor', 500, 300, false);
		editor.addCommand(pluginName, new CKEDITOR.dialogCommand(pluginName));

		editor.ui.addButton( 'frontendmodules',
			{
				label : 'Select fontendmodule',
				command : 'frontendmodules',
				icon: CKEDITOR.basePath + '/plugins/frontendmodules/frontendmodules.gif'
			});
		
	}
});


function showDialogPlugin(e){
    alert('helloworld.dlg');
    new CKEDITOR.dialogCommand( 'frontendmodules', 'Module', '/modules/init/editor', 500, 350 ) ;
}