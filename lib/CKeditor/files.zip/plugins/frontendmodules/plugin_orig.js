﻿/*
 * FCKeditor - The text editor for Internet - http://www.fckeditor.net
 * Copyright (C) 2003-2009 Frederico Caldeira Knabben
 *
 * == BEGIN LICENSE ==
 *
 * Licensed under the terms of any of the following licenses at your
 * choice:
 *
 *  - GNU General Public License Version 2 or later (the "GPL")
 *    http://www.gnu.org/licenses/gpl.html
 *
 *  - GNU Lesser General Public License Version 2.1 or later (the "LGPL")
 *    http://www.gnu.org/licenses/lgpl.html
 *
 *  - Mozilla Public License Version 1.1 or later (the "MPL")
 *    http://www.mozilla.org/MPL/MPL-1.1.html
 *
 * == END LICENSE ==
 *
 * This plugin register Toolbar items to manage frontend modules 
 */

// Our method which is called during initialization of the toolbar.
function FrontendModules()
{
}

// Disable button toggling.
FrontendModules.prototype.GetState = function()
{
	return CK_TRISTATE_OFF;
}

// Our method which is called on button click.
FrontendModules.prototype.Execute = function()
{
alert ("hallo");
}

CKEDITOR.plugins.add('frontendmodules', {
	init : function( editor )
	{
		editor.addCommand( 'frontendmodules', new CKEDITOR.dialogCommand( 'frontendmodules', 'Module', '/modules/init/editor', 500, 350 ) );
 
		editor.ui.addButton( 'frontendmodules',
			{
				label : 'Frontend Modules',
				command : 'frontendmodules',
				icon: 'plugins/frontendmodules/frontendmodules.gif'
			});
        
		 CKEDITOR.dialog.add( 'frontendmodules', '/modules/init/editor');
		 //CKEDITOR.dialog.add( 'frontendmodules', CKEDITOR.basePath + 'web/frontend/modules/init/editor');
		 //CKEDITOR.dialog.add( 'frontendmodules', '/file/10/824670.jpg');
 
	}
});
